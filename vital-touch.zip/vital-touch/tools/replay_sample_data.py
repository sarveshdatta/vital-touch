"""Send sample_data/sample_readings.json to a running backend, one reading per second.

Exercises the same endpoint the ESP32 uses, so the dashboard can be tested
without hardware. Standard library only.

Usage:
    python tools/replay_sample_data.py --url http://localhost:5000 --key <VT_DEVICE_API_KEY>
"""

import argparse
import json
import time
import urllib.error
import urllib.request
from pathlib import Path

SAMPLE_FILE = Path(__file__).resolve().parents[1] / "sample_data" / "sample_readings.json"


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--url", default="http://localhost:5000")
    parser.add_argument("--key", required=True, help="device API key (VT_DEVICE_API_KEY)")
    parser.add_argument("--delay", type=float, default=1.0, help="seconds between readings")
    args = parser.parse_args()

    readings = json.loads(SAMPLE_FILE.read_text())
    for i, reading in enumerate(readings, start=1):
        req = urllib.request.Request(
            f"{args.url.rstrip('/')}/api/readings",
            data=json.dumps(reading).encode(),
            headers={"Content-Type": "application/json", "X-API-Key": args.key},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as res:
                saved = json.loads(res.read())
                print(f"[{i:02d}] HR={reading['heart_rate']} SpO2={reading['spo2']} -> {saved['status']}")
        except urllib.error.HTTPError as err:
            print(f"[{i:02d}] rejected: HTTP {err.code} {err.read().decode()}")
        time.sleep(args.delay)


if __name__ == "__main__":
    main()
